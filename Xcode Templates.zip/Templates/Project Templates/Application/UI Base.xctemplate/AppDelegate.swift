/*
 *  ___FILENAME___
 *  ___PROJECTNAME___
 *
 *  Created by ___FULLUSERNAME___ on ___DATE___.
 *  Copyright ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
 */

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

// MARK: - Properties

    var window: UIWindow?

// MARK: - Protected Methods

// MARK: - Exposed Methods

    func application(_ application: UIApplication,
					 didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Keep in mind that as a Micro-Feature (Framework), 
        // this AppDelegate file will be completely ignored when imported.
        return true
    }

// MARK: - Overridden Methods
}
