/*
 *	___FILENAME___
 *	___PROJECTNAME___
 *
 *	Created by ___VARIABLE_authors___ on ___DATE___.
 *	Copyright ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
 */

import Foundation

// MARK: - Definitions -

// MARK: - Type -

enum ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_extendedType___ {

  case case1

// MARK: - Properties

// MARK: - Constructors

// MARK: - Protected Methods

// MARK: - Exposed Methods

// MARK: - Overridden Methods

}
