/*
 *  ___FILENAME___
 *  ___PROJECTNAME___
 *
 *  Created by ___FULLUSERNAME___ on ___DATE___.
 *  Copyright ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
 */

#import <Foundation/Foundation.h>

// MARK: - Definitions -

// Framework identification.
static const double k___PACKAGENAMEASIDENTIFIER___Version = 1.0;
static NSString *const k___PACKAGENAMEASIDENTIFIER___Name = @"___PACKAGENAMEASIDENTIFIER___";
