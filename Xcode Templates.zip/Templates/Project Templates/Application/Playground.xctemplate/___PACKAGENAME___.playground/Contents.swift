//: Playground - noun: a place where people can play

import Foundation
import ___PACKAGENAME___

var str = "Hello, ___PACKAGENAME___"
