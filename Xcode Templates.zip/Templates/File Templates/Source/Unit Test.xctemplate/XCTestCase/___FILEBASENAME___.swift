/*
 *	___FILENAME___
 *	___PROJECTNAME___
 *
 *	Created by ___VARIABLE_authors___ on ___DATE___.
 *	Copyright ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
 */

import XCTest
@testable import ___PACKAGENAME___

// MARK: - Definitions -

// MARK: - Type -

class ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_testSubclass___ {

// MARK: - Properties

// MARK: - Constructors

// MARK: - Protected Methods

// MARK: - Exposed Methods

  func test_WHAT_HOW_WHY() {
    // WHAT is being tested,
    // HOW is it being tested (under which state/condition) and
    // WHY is it being tested.
  }

// MARK: - Overridden Methods

}
