/*
 *  ___FILENAME___
 *  ___PROJECTNAME___
 *
 *  Created by ___FULLUSERNAME___ on ___DATE___.
 *  Copyright ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
 */

import XCTest
@testable import ___PROJECTNAME___

// MARK: - Definitions -

// MARK: - Type -

class ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_testSubclass___ {

// MARK: - Properties

// MARK: - Protected Methods

// MARK: - Exposed Methods

// MARK: - Overridden Methods

	func test_WHAT_HOW_WHY() {
		// WHAT is being tested,
		// HOW is it being tested (under which state/condition) and
		// WHY is it being tested.
	}
}
