/*
 *	___FILENAME___
 *	___PROJECTNAME___
 *
 *	Created by ___VARIABLE_authors___ on ___DATE___.
 *	Copyright ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
 */

import Quick
import Nimble
@testable import ___PACKAGENAME___

// MARK: - Definitions -

// MARK: - Type -

class ___FILEBASENAMEASIDENTIFIER___ : QuickSpec {

// MARK: - Properties

// MARK: - Protected Methods

// MARK: - Exposed Methods

// MARK: - Overridden Methods

	override func spec() {

		describe("WHAT is being tested") {

			context("HOW is going to be tested, under which state/condition") {

				it("WHY is this test being done, explain the expected behavior/result") {
					expect("string").to(equal("string"))
				}
			}
		}
	}
}
